import { apiRequest } from "@/lib/queryClient";

// Types for authentication
interface User {
  id: number;
  username: string;
  isAdmin: boolean;
}

interface AuthResponse {
  user: User;
  accessToken: string;
}

// Check if user is authenticated
export async function isAuthenticated(): Promise<boolean> {
  try {
    // Check if we have the token
    const token = localStorage.getItem("authToken");
    if (!token) {
      return false;
    }

    // Verify token with the server
    const response = await fetch("/api/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      credentials: "include",
    });

    if (!response.ok) {
      // Clear invalid tokens
      if (response.status === 401 || response.status === 403) {
        localStorage.removeItem("authToken");
        localStorage.removeItem("user");
      }
      return false;
    }

    return true;
  } catch (error) {
    console.error("Error checking authentication:", error);
    return false;
  }
}

// Get current user from localStorage
export function getCurrentUser(): User | null {
  try {
    const userJson = localStorage.getItem("user");
    if (!userJson) return null;
    
    return JSON.parse(userJson);
  } catch (error) {
    console.error("Error parsing user from localStorage:", error);
    return null;
  }
}

// Register function
export async function register(username: string, password: string) {
  const response = await apiRequest("POST", "/api/auth/register", { 
    username, 
    password 
  });
  
  return await response.json();
}

// Login function
export async function login(username: string, password: string): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/login", { 
    username, 
    password 
  });
  
  const data = await response.json();
  
  // Store auth data in localStorage
  localStorage.setItem("authToken", data.accessToken);
  localStorage.setItem("user", JSON.stringify(data.user));
  
  return data;
}

// Logout function
export function logout() {
  localStorage.removeItem("authToken");
  localStorage.removeItem("user");
}

// Get authorization header for API requests
export function getAuthHeader() {
  const token = localStorage.getItem("authToken");
  return token ? { Authorization: `Bearer ${token}` } : {};
}
