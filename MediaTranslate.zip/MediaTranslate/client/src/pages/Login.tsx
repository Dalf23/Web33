import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const loginMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/login", { username, password });
      return res.json();
    },
    onSuccess: (data) => {
      // تسجيل بيانات الاستجابة للتشخيص
      console.log("Login response:", data);
      
      if (!data.accessToken) {
        console.error("No access token returned from server");
        toast({
          title: "خطأ في تسجيل الدخول",
          description: "لم يتم استلام رمز التوثيق من الخادم",
          variant: "destructive"
        });
        return;
      }
      
      // حفظ الرمز المميز في localStorage
      localStorage.setItem("authToken", data.accessToken);
      localStorage.setItem("user", JSON.stringify(data.user));
      
      // تسجيل الرمز المميز المخزن للتأكد
      console.log("Stored token:", localStorage.getItem("authToken"));
      
      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: `مرحباً ${data.user.username}`,
      });
      
      // Navigate to admin for admin users, otherwise to home
      if (data.user.isAdmin) {
        navigate("/admin");
      } else {
        navigate("/");
      }
    },
    onError: (error: any) => {
      toast({
        title: "فشل تسجيل الدخول",
        description: error.message || "اسم المستخدم أو كلمة المرور غير صحيحة",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم المستخدم وكلمة المرور",
        variant: "destructive"
      });
      return;
    }
    
    loginMutation.mutate({ username, password });
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-[80vh] flex items-center justify-center">
      <Card className="bg-card p-8 rounded-lg shadow-lg max-w-md w-full">
        <CardContent className="p-0">
          <div className="text-center mb-8">
            <h1 className="text-primary text-3xl font-bold mb-2">سينماوي</h1>
            <p className="text-muted-foreground">تسجيل الدخول</p>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <Label htmlFor="username" className="block text-foreground mb-2">
                اسم المستخدم
              </Label>
              <Input 
                type="text" 
                id="username" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-card border border-border rounded-md px-4 py-2 text-foreground"
              />
            </div>
            <div className="mb-6">
              <Label htmlFor="password" className="block text-foreground mb-2">
                كلمة المرور
              </Label>
              <Input 
                type="password" 
                id="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-card border border-border rounded-md px-4 py-2 text-foreground"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-2 px-4 rounded-md transition mb-4"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "جاري التسجيل..." : "تسجيل الدخول"}
            </Button>
            <div className="text-center">
              <p className="text-muted-foreground text-sm">
                ليس لديك حساب؟{" "}
                <Link href="/register">
                  <a className="text-primary hover:underline">إنشاء حساب جديد</a>
                </Link>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
