import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import SeriesForm from '@/components/SeriesForm';
import EpisodeForm from '@/components/EpisodeForm';
import MovieForm from '@/components/MovieForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import ContentCard from '@/components/ContentCard';
import EpisodeCard from '@/components/EpisodeCard';

type Tab = 'add' | 'series' | 'movies';
type ContentType = 'series' | 'movie';

export default function Admin() {
  const [tab, setTab] = useState<Tab>('add');
  const [contentType, setContentType] = useState<ContentType>('series');
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Check authentication on mount
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    if (!token) {
      navigate('/login');
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("user");
    navigate('/login');
    
    toast({
      title: "تم تسجيل الخروج",
      description: "تم تسجيل خروجك بنجاح"
    });
  };

  // Fetch series for management
  const { data: allSeries } = useQuery({
    queryKey: ['/api/series', { type: 'series' }],
    queryFn: () => fetch('/api/series?type=series').then(res => res.json())
  });

  // Fetch movies for management
  const { data: allMovies } = useQuery({
    queryKey: ['/api/series', { type: 'movie' }],
    queryFn: () => fetch('/api/series?type=movie').then(res => res.json())
  });

  // Get username from local storage
  const username = (() => {
    try {
      const user = localStorage.getItem("user");
      if (user) {
        return JSON.parse(user).username;
      }
      return "الإدارة";
    } catch (error) {
      return "الإدارة";
    }
  })();

  return (
    <div>
      <div className="bg-card shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <h1 className="text-primary text-2xl font-bold">سينماوي</h1>
              <span className="mr-2 text-muted-foreground">لوحة التحكم</span>
            </div>
            <div className="flex items-center">
              <span className="text-foreground ml-4">مرحباً، {username}</span>
              <Button 
                variant="outline" 
                onClick={handleLogout}
                className="bg-card text-foreground"
              >
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <Tabs value={tab} onValueChange={(value) => setTab(value as Tab)}>
          <TabsList className="mb-6">
            <TabsTrigger value="add" className={tab === 'add' ? 'tab-active' : ''}>
              إضافة محتوى
            </TabsTrigger>
            <TabsTrigger value="series" className={tab === 'series' ? 'tab-active' : ''}>
              إدارة المسلسلات
            </TabsTrigger>
            <TabsTrigger value="movies" className={tab === 'movies' ? 'tab-active' : ''}>
              إدارة الأفلام
            </TabsTrigger>
          </TabsList>

          <TabsContent value="add">
            <Card className="bg-card p-6 rounded-lg shadow-md mb-10">
              <CardContent className="p-0">
                <h2 className="text-xl font-bold mb-6">إضافة محتوى جديد</h2>

                <div className="mb-6">
                  <div className="flex space-x-4 space-x-reverse mb-6">
                    <Button 
                      variant={contentType === 'series' ? 'default' : 'outline'}
                      onClick={() => setContentType('series')}
                      className={contentType === 'series' ? 'bg-primary text-white' : 'bg-card text-muted-foreground'}
                    >
                      مسلسل
                    </Button>
                    <Button 
                      variant={contentType === 'movie' ? 'default' : 'outline'}
                      onClick={() => setContentType('movie')}
                      className={contentType === 'movie' ? 'bg-primary text-white' : 'bg-card text-muted-foreground'}
                    >
                      فيلم
                    </Button>
                  </div>

                  {contentType === 'series' ? <SeriesForm /> : <MovieForm />}
                </div>

                {contentType === 'series' && (
                  <>
                    <hr className="border-border my-8" />
                    <h3 className="text-lg font-bold mb-6">إضافة حلقة جديدة</h3>
                    <EpisodeForm series={allSeries || []} />
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="series">
            <Card className="bg-card p-6 rounded-lg shadow-md mb-10">
              <CardContent className="p-0">
                <h2 className="text-xl font-bold mb-6">إدارة المسلسلات</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {(allSeries || []).map((series) => (
                    <div key={series.id} className="relative group">
                      <ContentCard item={series} type="series" />
                      <div className="absolute inset-0 bg-background/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="flex space-x-2 space-x-reverse">
                          <Button variant="destructive" size="sm">حذف</Button>
                          <Button variant="outline" size="sm">تعديل</Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="movies">
            <Card className="bg-card p-6 rounded-lg shadow-md mb-10">
              <CardContent className="p-0">
                <h2 className="text-xl font-bold mb-6">إدارة الأفلام</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {(allMovies || []).map((movie) => (
                    <div key={movie.id} className="relative group">
                      <ContentCard item={movie} type="movie" />
                      <div className="absolute inset-0 bg-background/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="flex space-x-2 space-x-reverse">
                          <Button variant="destructive" size="sm">حذف</Button>
                          <Button variant="outline" size="sm">تعديل</Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
