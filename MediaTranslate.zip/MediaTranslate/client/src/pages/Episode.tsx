import { useQuery } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import VideoPlayer from "@/components/VideoPlayer";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function Episode() {
  const params = useParams<{ id: string }>();
  const id = params?.id ? parseInt(params.id) : null;
  const [, navigate] = useLocation();

  // Fetch episode data
  const { data: episode, isLoading: episodeLoading } = useQuery({
    queryKey: [`/api/episodes/${id}`],
    queryFn: () => fetch(`/api/episodes/${id}`).then(res => res.json()),
    enabled: !!id
  });

  // Fetch series data once we have the episode
  const { data: series, isLoading: seriesLoading } = useQuery({
    queryKey: [`/api/series/${episode?.seriesId}`],
    queryFn: () => fetch(`/api/series/${episode?.seriesId}`).then(res => res.json()),
    enabled: !!episode?.seriesId
  });
  
  const isLoading = episodeLoading || seriesLoading;

  if (!id) {
    navigate('/not-found');
    return null;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Skeleton className="h-6 w-48 mb-4" />
        <Skeleton className="h-8 w-96 mb-2" />
        <Skeleton className="h-4 w-32 mb-6" />
        <Skeleton className="w-full h-[500px] rounded-lg mb-6" />
        <Skeleton className="h-6 w-48 mb-3" />
        <Skeleton className="h-24 w-full mb-8" />
      </div>
    );
  }

  if (!episode || !series) {
    navigate('/not-found');
    return null;
  }

  const otherEpisodes = series.episodes
    .filter(ep => ep.id !== episode.id)
    .sort((a, b) => a.episodeNumber - b.episodeNumber);

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-4">
        <Link href={`/series/${series.id}`}>
          <a className="text-muted-foreground hover:text-primary transition flex items-center mb-4">
            <ArrowRight className="ml-2 h-4 w-4" /> العودة إلى المسلسل
          </a>
        </Link>
        <h1 className="text-2xl font-bold">{series.title} - الحلقة {episode.episodeNumber}</h1>
        {episode.title && (
          <h2 className="text-xl mb-2">{episode.title}</h2>
        )}
        <div className="text-muted-foreground text-sm mb-4">مدة الحلقة: {episode.duration} دقيقة</div>
      </div>

      <div className="bg-card rounded-lg overflow-hidden mb-6">
        <VideoPlayer 
          videoUrl={episode.videoUrl} 
          subtitleUrl={episode.subtitleUrl}
          thumbnailUrl={episode.thumbnailUrl || series.thumbnailUrl}
        />
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-3">وصف الحلقة</h2>
        <p className="text-muted-foreground">{episode.description}</p>
      </div>

      {otherEpisodes.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">حلقات أخرى</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {otherEpisodes.slice(0, 4).map(ep => (
              <div key={ep.id} className="bg-card rounded-lg overflow-hidden content-card">
                <Link href={`/episode/${ep.id}`}>
                  <a>
                    <img 
                      src={ep.thumbnailUrl || series.thumbnailUrl} 
                      alt={`الحلقة ${ep.episodeNumber}`} 
                      className="w-full h-36 object-cover" 
                    />
                    <div className="p-3">
                      <h3 className="font-bold mb-1">الحلقة {ep.episodeNumber}</h3>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">{ep.duration} دقيقة</span>
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                          <i className="fas fa-play"></i>
                        </Button>
                      </div>
                    </div>
                  </a>
                </Link>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
