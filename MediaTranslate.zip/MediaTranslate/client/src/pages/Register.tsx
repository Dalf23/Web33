import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const registerMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/register", { username, password });
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم إنشاء الحساب بنجاح",
        description: "يمكنك الآن تسجيل الدخول باستخدام بياناتك",
      });
      
      navigate("/login");
    },
    onError: (error: any) => {
      toast({
        title: "فشل إنشاء الحساب",
        description: error.message || "حدث خطأ أثناء التسجيل. ربما يكون اسم المستخدم موجودًا بالفعل.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password || !confirmPassword) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }
    
    if (password !== confirmPassword) {
      toast({
        title: "خطأ",
        description: "كلمات المرور غير متطابقة",
        variant: "destructive"
      });
      return;
    }
    
    if (password.length < 6) {
      toast({
        title: "خطأ",
        description: "يجب أن تحتوي كلمة المرور على 6 أحرف على الأقل",
        variant: "destructive"
      });
      return;
    }
    
    registerMutation.mutate({ username, password });
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-[80vh] flex items-center justify-center">
      <Card className="bg-card p-8 rounded-lg shadow-lg max-w-md w-full">
        <CardContent className="p-0">
          <div className="text-center mb-8">
            <h1 className="text-primary text-3xl font-bold mb-2">سينماوي</h1>
            <p className="text-muted-foreground">إنشاء حساب جديد</p>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <Label htmlFor="username" className="block text-foreground mb-2">
                اسم المستخدم
              </Label>
              <Input 
                type="text" 
                id="username" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-card border border-border rounded-md px-4 py-2 text-foreground"
              />
            </div>
            <div className="mb-4">
              <Label htmlFor="password" className="block text-foreground mb-2">
                كلمة المرور
              </Label>
              <Input 
                type="password" 
                id="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-card border border-border rounded-md px-4 py-2 text-foreground"
              />
            </div>
            <div className="mb-6">
              <Label htmlFor="confirmPassword" className="block text-foreground mb-2">
                تأكيد كلمة المرور
              </Label>
              <Input 
                type="password" 
                id="confirmPassword" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-card border border-border rounded-md px-4 py-2 text-foreground"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-2 px-4 rounded-md transition mb-4"
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? "جاري التسجيل..." : "إنشاء حساب"}
            </Button>
            <div className="text-center">
              <p className="text-muted-foreground text-sm">
                لديك حساب بالفعل؟{" "}
                <Link href="/login">
                  <a className="text-primary hover:underline">تسجيل الدخول</a>
                </Link>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}