import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import FeaturedSlider from "@/components/FeaturedSlider";
import ContentCard from "@/components/ContentCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [genreFilter, setGenreFilter] = useState<string>("");
  const [yearFilter, setYearFilter] = useState<string>("");
  
  // Fetch featured content
  const { data: featuredContent, isLoading: featuredLoading } = useQuery({
    queryKey: ['/api/series', { featured: true }],
    queryFn: () => fetch('/api/series?featured=true').then(res => res.json())
  });
  
  // Fetch latest series
  const { data: latestSeries, isLoading: seriesLoading } = useQuery({
    queryKey: ['/api/series', { type: 'series', genre: genreFilter, year: yearFilter }],
    queryFn: () => {
      let url = '/api/series?type=series';
      if (genreFilter) url += `&genre=${genreFilter}`;
      if (yearFilter) url += `&year=${yearFilter}`;
      return fetch(url).then(res => res.json());
    }
  });
  
  // Fetch latest movies
  const { data: latestMovies, isLoading: moviesLoading } = useQuery({
    queryKey: ['/api/series', { type: 'movie', genre: genreFilter, year: yearFilter }],
    queryFn: () => {
      let url = '/api/series?type=movie';
      if (genreFilter) url += `&genre=${genreFilter}`;
      if (yearFilter) url += `&year=${yearFilter}`;
      return fetch(url).then(res => res.json());
    }
  });
  
  const genres = ["جميع الأنواع", "دراما", "كوميديا", "أكشن", "خيال علمي", "رعب", "غموض"];
  const years = ["جميع السنوات", "2023", "2022", "2021", "2020", "2019"];
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Featured Content Slider */}
      {featuredLoading ? (
        <div className="relative mb-10 overflow-hidden rounded-xl">
          <Skeleton className="w-full h-[400px] rounded-xl" />
        </div>
      ) : (
        <FeaturedSlider items={featuredContent || []} />
      )}

      {/* Content Filters */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">تصفح المحتوى</h2>
          <div className="flex space-x-3 space-x-reverse">
            <select 
              className="bg-card text-foreground px-3 py-2 rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
              value={genreFilter}
              onChange={(e) => setGenreFilter(e.target.value)}
            >
              {genres.map((genre, index) => (
                <option key={index} value={index === 0 ? "" : genre}>
                  {genre}
                </option>
              ))}
            </select>
            <select 
              className="bg-card text-foreground px-3 py-2 rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
            >
              {years.map((year, index) => (
                <option key={index} value={index === 0 ? "" : year}>
                  {year}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Latest Series Section */}
      <div className="mb-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">أحدث المسلسلات</h2>
          <a href="#" className="text-primary hover:text-red-400 transition">عرض الكل</a>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {seriesLoading ? (
            Array(5).fill(null).map((_, i) => (
              <div key={i} className="bg-card rounded-lg overflow-hidden">
                <Skeleton className="w-full h-60" />
                <div className="p-3">
                  <Skeleton className="h-6 w-2/3 mb-2" />
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            (latestSeries || []).slice(0, 5).map((series) => (
              <ContentCard 
                key={series.id} 
                item={series} 
                type="series" 
              />
            ))
          )}
        </div>
      </div>

      {/* Latest Movies Section */}
      <div className="mb-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">أحدث الأفلام</h2>
          <a href="#" className="text-primary hover:text-red-400 transition">عرض الكل</a>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {moviesLoading ? (
            Array(5).fill(null).map((_, i) => (
              <div key={i} className="bg-card rounded-lg overflow-hidden">
                <Skeleton className="w-full h-60" />
                <div className="p-3">
                  <Skeleton className="h-6 w-2/3 mb-2" />
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            (latestMovies || []).slice(0, 5).map((movie) => (
              <ContentCard 
                key={movie.id} 
                item={movie} 
                type="movie" 
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
