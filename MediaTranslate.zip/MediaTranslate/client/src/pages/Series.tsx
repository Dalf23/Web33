import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import EpisodeCard from "@/components/EpisodeCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Share } from "lucide-react";

export default function Series() {
  const params = useParams<{ id: string }>();
  const id = params?.id ? parseInt(params.id) : null;
  const [, navigate] = useLocation();
  
  const { data: seriesData, isLoading } = useQuery({
    queryKey: [`/api/series/${id}`],
    queryFn: () => fetch(`/api/series/${id}`).then(res => res.json()),
    enabled: !!id
  });

  if (!id) {
    navigate('/not-found');
    return null;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="mb-8 relative rounded-xl overflow-hidden">
          <Skeleton className="w-full h-[400px]" />
        </div>
        <Skeleton className="h-8 w-48 mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array(3).fill(null).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (!seriesData) {
    navigate('/not-found');
    return null;
  }

  const { title, description, thumbnailUrl, bannerUrl, genre, year, episodes, type } = seriesData;
  const imageUrl = bannerUrl || thumbnailUrl || "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400&q=80";

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-8 relative rounded-xl overflow-hidden">
        <div className="w-full h-[400px] relative">
          <img 
            src={imageUrl} 
            className="w-full h-full object-cover opacity-60" 
            alt={title} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-card/50 to-transparent"></div>
          <div className="absolute bottom-10 right-10 max-w-3xl text-right">
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="bg-card text-foreground px-3 py-1 rounded-md text-sm">{genre}</span>
              <span className="bg-card text-foreground px-3 py-1 rounded-md text-sm">{year}</span>
              {type === 'series' && (
                <span className="bg-card text-foreground px-3 py-1 rounded-md text-sm">
                  {episodes?.length || 0} حلقة
                </span>
              )}
              {type === 'movie' && (
                <span className="bg-card text-foreground px-3 py-1 rounded-md text-sm">
                  {seriesData.duration} دقيقة
                </span>
              )}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">{title}</h1>
            <p className="text-muted-foreground mb-4 text-sm md:text-base">{description}</p>
            <div className="flex space-x-3 space-x-reverse">
              <Button className="bg-primary hover:bg-primary/90">
                <i className="fas fa-play ml-2"></i> شاهد الآن
              </Button>
              <Button variant="outline" className="bg-card hover:bg-card/90">
                <Share className="ml-2 h-4 w-4" /> مشاركة
              </Button>
            </div>
          </div>
        </div>
      </div>

      {type === 'series' && episodes && episodes.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">الحلقات</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {episodes.map((episode) => (
              <EpisodeCard key={episode.id} episode={episode} seriesTitle={title} />
            ))}
          </div>
        </div>
      )}

      {type === 'movie' && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">مشاهدة الفيلم</h2>
          <div className="bg-card rounded-lg overflow-hidden">
            <div className="aspect-w-16 aspect-h-9 bg-background">
              <div className="w-full h-[500px] flex items-center justify-center bg-background relative">
                <img 
                  src={thumbnailUrl || imageUrl} 
                  className="w-full h-full object-cover opacity-50" 
                  alt={title} 
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <button className="bg-primary/80 hover:bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center transition">
                    <i className="fas fa-play text-2xl"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
