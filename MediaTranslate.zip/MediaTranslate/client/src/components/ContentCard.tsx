import { Link } from "wouter";
import { Series } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface ContentCardProps {
  item: Series;
  type: 'series' | 'movie';
}

export default function ContentCard({ item, type }: ContentCardProps) {
  return (
    <Link href={`/series/${item.id}`}>
      <a className="content-card bg-card rounded-lg overflow-hidden block">
        <div className="relative">
          <img 
            src={item.thumbnailUrl || 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=450&q=80'} 
            alt={item.title} 
            className="w-full h-60 object-cover" 
          />
          {item.isFeatured && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-primary text-white text-xs px-2 py-1 rounded">
                {type === 'series' ? 'جديد' : 'حصري'}
              </Badge>
            </div>
          )}
        </div>
        <div className="p-3">
          <h3 className="font-bold text-lg mb-1 line-clamp-1">{item.title}</h3>
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>{item.year}</span>
            <span>{item.genre}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">
              {type === 'series' 
                ? `حلقات: ${item.episodeCount || 0}`
                : `${item.duration || 0} دقيقة`
              }
            </span>
            <button className="text-primary hover:text-primary/90">
              <i className="fas fa-play"></i>
            </button>
          </div>
        </div>
      </a>
    </Link>
  );
}
