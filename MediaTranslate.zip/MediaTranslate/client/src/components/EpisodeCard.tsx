import { Link } from "wouter";
import { Episode } from "@shared/schema";

interface EpisodeCardProps {
  episode: Episode;
  seriesTitle: string;
}

export default function EpisodeCard({ episode, seriesTitle }: EpisodeCardProps) {
  return (
    <Link href={`/episode/${episode.id}`}>
      <a className="bg-card rounded-lg overflow-hidden flex">
        <div className="w-1/3">
          <img 
            src={episode.thumbnailUrl || 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=100&q=80'} 
            alt={`${seriesTitle} - الحلقة ${episode.episodeNumber}`} 
            className="w-full h-full object-cover" 
          />
        </div>
        <div className="w-2/3 p-3">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold">
              الحلقة {episode.episodeNumber}
              {episode.title && ` - ${episode.title}`}
            </h3>
            <span className="text-xs text-muted-foreground">{episode.duration} دقيقة</span>
          </div>
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {episode.description}
          </p>
          <button className="text-primary hover:text-primary/90 text-sm flex items-center">
            <i className="fas fa-play ml-1"></i> شاهد الآن
          </button>
        </div>
      </a>
    </Link>
  );
}
