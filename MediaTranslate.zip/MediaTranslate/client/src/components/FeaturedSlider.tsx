import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Series } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface FeaturedSliderProps {
  items: Series[];
}

export default function FeaturedSlider({ items }: FeaturedSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Auto-advance slide every 6 seconds
  useEffect(() => {
    if (items.length <= 1) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((current) => (current + 1) % items.length);
    }, 6000);
    
    return () => clearInterval(interval);
  }, [items.length]);
  
  const goToPrevious = () => {
    setCurrentIndex((current) => {
      if (current === 0) {
        return items.length - 1;
      }
      return current - 1;
    });
  };
  
  const goToNext = () => {
    setCurrentIndex((current) => (current + 1) % items.length);
  };
  
  if (items.length === 0) {
    return (
      <div className="relative mb-10 overflow-hidden rounded-xl">
        <div className="w-full h-[400px] bg-gradient-to-r from-background to-card rounded-xl overflow-hidden relative flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold">لا يوجد محتوى مميز حالياً</h2>
            <p className="text-muted-foreground mt-2">سيتم إضافة محتوى مميز قريباً</p>
          </div>
        </div>
      </div>
    );
  }
  
  const currentItem = items[currentIndex];
  
  return (
    <div className="relative mb-10 overflow-hidden rounded-xl">
      <div className="w-full h-[400px] bg-gradient-to-r from-background to-card rounded-xl overflow-hidden relative">
        <img 
          src={currentItem.thumbnailUrl || "https://images.unsplash.com/photo-1616530940355-351fabd9524b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400&q=80"} 
          className="w-full h-full object-cover opacity-60" 
          alt={currentItem.title} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        <div className="absolute bottom-10 right-10 max-w-xl text-right">
          <Badge variant="default" className="bg-primary text-white px-3 py-1 rounded-md text-sm mb-3 inline-block">
            {currentItem.type === 'series' ? 'مسلسل جديد' : 'فيلم جديد'}
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">{currentItem.title}</h2>
          <p className="text-muted-foreground mb-4 text-sm md:text-base line-clamp-2 md:line-clamp-3">
            {currentItem.description}
          </p>
          <div className="flex space-x-3 space-x-reverse">
            <Link href={`/series/${currentItem.id}`}>
              <Button className="bg-primary hover:bg-primary/90 text-white">
                <i className="fas fa-play ml-2"></i> شاهد الآن
              </Button>
            </Link>
            <Link href={`/series/${currentItem.id}`}>
              <Button variant="outline" className="bg-card hover:bg-card/90 text-foreground">
                <i className="fas fa-info-circle ml-2"></i> التفاصيل
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {items.length > 1 && (
        <>
          <div className="absolute left-5 top-1/2 transform -translate-y-1/2">
            <Button 
              onClick={goToPrevious}
              variant="outline"
              size="icon"
              className="bg-card/70 hover:bg-card text-foreground w-10 h-10 rounded-full flex items-center justify-center"
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </div>
          <div className="absolute right-5 top-1/2 transform -translate-y-1/2">
            <Button 
              onClick={goToNext}
              variant="outline"
              size="icon"
              className="bg-card/70 hover:bg-card text-foreground w-10 h-10 rounded-full flex items-center justify-center"
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          </div>
          <div className="absolute bottom-3 left-0 right-0 flex justify-center space-x-2">
            {items.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentIndex ? "bg-primary w-4" : "bg-card"
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
