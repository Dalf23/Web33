import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { getCurrentUser } from "@/lib/auth";
import { Skeleton } from "@/components/ui/skeleton";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

export default function ProtectedRoute({ children, requireAdmin = true }: ProtectedRouteProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      setLoading(true);
      
      try {
        const user = getCurrentUser();
        
        if (!user) {
          toast({
            title: "غير مصرح",
            description: "يجب تسجيل الدخول للوصول إلى هذه الصفحة",
            variant: "destructive",
          });
          navigate("/login");
          return;
        }
        
        // Check if admin access is required
        if (requireAdmin && !user.isAdmin) {
          toast({
            title: "وصول محظور",
            description: "لا تملك صلاحيات كافية للوصول إلى هذه الصفحة",
            variant: "destructive",
          });
          navigate("/");
          return;
        }
        
        setAuthorized(true);
      } catch (error) {
        console.error("Authentication check failed:", error);
        toast({
          title: "خطأ في التحقق",
          description: "حدث خطأ أثناء التحقق من صلاحيات الوصول",
          variant: "destructive",
        });
        navigate("/login");
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [navigate, toast, requireAdmin]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-8 w-24" />
        </div>
        <Skeleton className="h-[600px] w-full rounded-lg" />
      </div>
    );
  }

  return authorized ? <>{children}</> : null;
}
