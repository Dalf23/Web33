import { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";

interface VideoPlayerProps {
  videoUrl: string;
  subtitleUrl?: string;
  thumbnailUrl?: string;
}

export default function VideoPlayer({ videoUrl, subtitleUrl, thumbnailUrl }: VideoPlayerProps) {
  const videoRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    // إضافة معلومات تشخيصية
    console.log("معلومات تشخيصية لمشغل الفيديو:");
    console.log("1. عنوان الفيديو:", videoUrl);
    console.log("2. عنوان الترجمة:", subtitleUrl);
    console.log("3. عنوان الصورة المصغرة:", thumbnailUrl);
    
    // إضافة اختبار الوصول إلى الفيديو
    if (videoUrl) {
      console.log("جاري اختبار الوصول إلى ملف الفيديو...");
      fetch(videoUrl, { method: 'HEAD' })
        .then(response => {
          console.log("استجابة اختبار الفيديو:", response.status, response.statusText);
          console.log("نوع المحتوى:", response.headers.get('content-type'));
          console.log("حجم الملف:", response.headers.get('content-length'));
        })
        .catch(error => {
          console.error("خطأ في الوصول إلى الفيديو:", error);
        });
    }
    
    // Make sure Video.js player is only initialized once
    if (!playerRef.current) {
      const videoElement = document.createElement("video-js");
      videoElement.classList.add("vjs-big-play-centered");
      videoRef.current?.appendChild(videoElement);

      // تحديد نوع الفيديو بناءً على الرابط
      const getVideoType = (url: string) => {
        if (!url) return "video/mp4";
        
        // إذا كان الرابط هو رابط يوتيوب، نعيد نوع خاص
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
          return 'video/youtube';
        }
        
        // إذا كان الرابط هو عنوان URL لملف بدون امتداد أو مع علامات استفهام
        if (!url.includes('.') || url.includes('?')) {
          // نحاول تخمين نوع الفيديو من معلومات إضافية في الرابط
          if (url.includes('type=mp4') || url.includes('format=mp4')) {
            return 'video/mp4';
          } else if (url.includes('type=webm') || url.includes('format=webm')) {
            return 'video/webm';
          } else {
            // إذا لم نستطع تحديد النوع، نستخدم video/mp4 بشكل افتراضي للأرابط المباشرة
            console.log("لا يمكن تحديد نوع الفيديو من الرابط، استخدام النوع الافتراضي");
            return 'video/mp4';
          }
        }
        
        const extension = url.split('.').pop()?.toLowerCase().split('?')[0]; // نزيل أي معلمات URL
        
        // تنسيقات الفيديو الشائعة
        switch(extension) {
          case 'mp4': return 'video/mp4';
          case 'webm': return 'video/webm';
          case 'ogg': return 'video/ogg';
          case 'ogv': return 'video/ogg';
          case 'mov': return 'video/quicktime';
          case 'mkv': return 'video/x-matroska';
          case 'avi': return 'video/avi';
          case 'wmv': return 'video/x-ms-wmv';
          case 'flv': return 'video/x-flv';
          case 'm3u8': return 'application/x-mpegURL';
          case 'mpd': return 'application/dash+xml';
          case 'ts': return 'video/mp2t';
          // الافتراضي استخدام mp4
          default: return 'video/mp4';
        }
      };
      
      console.log("محاولة تشغيل الفيديو من الرابط:", videoUrl);
      console.log("نوع الفيديو المحدد:", getVideoType(videoUrl));
      
      playerRef.current = videojs(videoElement, {
        autoplay: false,
        controls: true,
        responsive: true,
        fluid: true,
        sources: [{
          src: videoUrl,
          type: getVideoType(videoUrl)
        }],
        poster: thumbnailUrl,
        preload: 'auto',
        html5: {
          vhs: {
            withCredentials: false,
            overrideNative: true
          },
          nativeAudioTracks: false,
          nativeVideoTracks: false,
          hls: {
            overrideNative: true
          }
        },
        crossOrigin: "anonymous"
      }, () => {
        console.log("مشغل الفيديو جاهز!");
        
        // إضافة معالجة الأخطاء
        playerRef.current.on('error', (error: any) => {
          console.error('خطأ في مشغل الفيديو:', playerRef.current.error());
          
          const errorDetails = {
            code: playerRef.current.error()?.code,
            message: playerRef.current.error()?.message,
            type: getVideoType(videoUrl),
            url: videoUrl
          };
          
          console.error('تفاصيل الخطأ:', errorDetails);
          
          // محاولة استخدام المشغل الأصلي للمتصفح كخيار احتياطي
          if (errorDetails.code === 4) {
            console.log('محاولة استخدام المشغل الأصلي للمتصفح...');
            
            const videoBackup = document.createElement('video');
            videoBackup.src = videoUrl;
            videoBackup.controls = true;
            videoBackup.width = 640;
            videoBackup.height = 360;
            videoBackup.style.width = '100%';
            videoBackup.style.height = '100%';
            
            if (thumbnailUrl) {
              videoBackup.poster = thumbnailUrl;
            }
            
            // إضافة المشغل البديل بعد تجهيز مشغل video.js
            playerRef.current.dispose();
            videoRef.current?.appendChild(videoBackup);
          }
        });
        // Player is ready
        playerRef.current.on("play", () => {
          setIsPlaying(true);
        });
        
        playerRef.current.on("pause", () => {
          setIsPlaying(false);
        });
      });

      // Add subtitles if available
      if (subtitleUrl) {
        playerRef.current.addRemoteTextTrack({
          kind: "subtitles",
          srclang: "ar",
          label: "العربية",
          src: subtitleUrl,
          default: true
        }, false);
      }
    } else {
      // وظيفة تحديد نوع الفيديو
      const getVideoType = (url: string) => {
        if (!url) return "video/mp4";
        
        // إذا كان الرابط هو رابط يوتيوب، نعيد نوع خاص
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
          return 'video/youtube';
        }
        
        // إذا كان الرابط هو عنوان URL لملف بدون امتداد أو مع علامات استفهام
        if (!url.includes('.') || url.includes('?')) {
          // نحاول تخمين نوع الفيديو من معلومات إضافية في الرابط
          if (url.includes('type=mp4') || url.includes('format=mp4')) {
            return 'video/mp4';
          } else if (url.includes('type=webm') || url.includes('format=webm')) {
            return 'video/webm';
          } else {
            // إذا لم نستطع تحديد النوع، نستخدم video/mp4 بشكل افتراضي للأرابط المباشرة
            console.log("لا يمكن تحديد نوع الفيديو من الرابط، استخدام النوع الافتراضي");
            return 'video/mp4';
          }
        }
        
        const extension = url.split('.').pop()?.toLowerCase().split('?')[0]; // نزيل أي معلمات URL
        
        // تنسيقات الفيديو الشائعة
        switch(extension) {
          case 'mp4': return 'video/mp4';
          case 'webm': return 'video/webm';
          case 'ogg': return 'video/ogg';
          case 'ogv': return 'video/ogg';
          case 'mov': return 'video/quicktime';
          case 'mkv': return 'video/x-matroska';
          case 'avi': return 'video/avi';
          case 'wmv': return 'video/x-ms-wmv';
          case 'flv': return 'video/x-flv';
          case 'm3u8': return 'application/x-mpegURL';
          case 'mpd': return 'application/dash+xml';
          case 'ts': return 'video/mp2t';
          // الافتراضي استخدام mp4
          default: return 'video/mp4';
        }
      };
      
      console.log("تحديث مصدر الفيديو:", videoUrl);
      console.log("نوع الفيديو المحدد:", getVideoType(videoUrl));
      
      // قبل تطبيق التغييرات على المصدر، نطبق نفس الإعدادات للـ html5
      if (playerRef.current.options_.html5) {
        playerRef.current.options_.html5.vhs = {
          withCredentials: false,
          overrideNative: true
        };
        playerRef.current.options_.html5.hls = {
          overrideNative: true
        };
        playerRef.current.options_.html5.nativeAudioTracks = false;
        playerRef.current.options_.html5.nativeVideoTracks = false;
      }
      
      // Update the player source if videoUrl changes
      playerRef.current.src({ src: videoUrl, type: getVideoType(videoUrl) });
      
      if (thumbnailUrl) {
        playerRef.current.poster(thumbnailUrl);
      }
      
      // Update subtitles if available
      if (subtitleUrl) {
        // Remove existing text tracks
        const textTracks = playerRef.current.textTracks();
        for (let i = 0; i < textTracks.length; i++) {
          playerRef.current.removeRemoteTextTrack(textTracks[i]);
        }
        
        // Add new subtitle track
        playerRef.current.addRemoteTextTrack({
          kind: "subtitles",
          srclang: "ar",
          label: "العربية",
          src: subtitleUrl,
          default: true
        }, false);
      }
    }
  }, [videoUrl, subtitleUrl, thumbnailUrl]);

  // Dispose the Video.js player when the component unmounts
  useEffect(() => {
    return () => {
      if (playerRef.current) {
        playerRef.current.dispose();
        playerRef.current = null;
      }
    };
  }, []);

  return (
    <div className="aspect-w-16 aspect-h-9 bg-background">
      <div ref={videoRef} className="w-full h-full" />
      
      {!isPlaying && !playerRef.current?.isFullscreen() && (
        <div className="absolute inset-0 flex items-center justify-center" 
             onClick={() => playerRef.current?.play()}
             style={{ pointerEvents: 'none' }}>
          <button className="bg-primary/80 hover:bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center transition"
                  style={{ pointerEvents: 'auto' }}>
            <i className="fas fa-play text-2xl"></i>
          </button>
        </div>
      )}
    </div>
  );
}
