import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertEpisodeSchema, InsertEpisode, Series } from "@shared/schema";
import { z } from "zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

// Extend the insert schema with additional validation
const formSchema = insertEpisodeSchema.extend({
  description: z.string().min(10, {
    message: "يجب أن يكون الوصف أكثر من 10 أحرف",
  }),
  videoUrl: z.string().url({
    message: "يجب أن يكون رابط صحيح",
  }),
  duration: z.number().int().min(1, {
    message: "يجب أن تكون المدة أكبر من صفر",
  }),
  episodeNumber: z.number().int().min(1, {
    message: "يجب أن يكون رقم الحلقة أكبر من صفر",
  }),
});

interface EpisodeFormProps {
  series: Series[];
}

export default function EpisodeForm({ series }: EpisodeFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string>("");
  const [subtitleFile, setSubtitleFile] = useState<File | null>(null);
  
  // Define form with react-hook-form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      seriesId: 0,
      title: "",
      description: "",
      videoUrl: "",
      duration: 0,
      episodeNumber: 1
    },
  });
  
  // Handle thumbnail selection
  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setThumbnail(file);
      
      // Preview
      const reader = new FileReader();
      reader.onload = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle subtitle file selection
  const handleSubtitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSubtitleFile(e.target.files[0]);
    }
  };
  
  // Create episode mutation
  const createEpisodeMutation = useMutation({
    mutationFn: async (data: InsertEpisode) => {
      // In a real implementation, we would handle file uploads here
      // For this demo, we'll just use the URL field
      
      const episodeData = {
        ...data,
        thumbnailUrl: thumbnailPreview || undefined,
        subtitleUrl: subtitleFile ? URL.createObjectURL(subtitleFile) : undefined
      };
      
      const res = await apiRequest("POST", "/api/episodes", episodeData);
      return res.json();
    },
    onSuccess: (data, variables) => {
      toast({
        title: "تم إضافة الحلقة بنجاح",
        description: `تمت إضافة الحلقة ${variables.episodeNumber} بنجاح`
      });
      
      // Reset form (but keep the selected series)
      const seriesId = form.getValues().seriesId;
      form.reset({
        seriesId,
        title: "",
        description: "",
        videoUrl: "",
        duration: 0,
        episodeNumber: form.getValues().episodeNumber + 1
      });
      setThumbnail(null);
      setThumbnailPreview("");
      setSubtitleFile(null);
      
      // Invalidate queries to refetch the data
      queryClient.invalidateQueries({ queryKey: ['/api/series'] });
      queryClient.invalidateQueries({ queryKey: [`/api/series/${seriesId}`] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إضافة الحلقة",
        description: error.message || "حدث خطأ أثناء إضافة الحلقة",
        variant: "destructive"
      });
    }
  });
  
  // Submit handler
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (data.seriesId === 0) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار المسلسل",
        variant: "destructive"
      });
      return;
    }
    
    createEpisodeMutation.mutate(data);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <FormField
            control={form.control}
            name="seriesId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>المسلسل</FormLabel>
                <Select 
                  onValueChange={(value) => field.onChange(parseInt(value))} 
                  defaultValue={field.value.toString()}
                >
                  <FormControl>
                    <SelectTrigger className="admin-input w-full rounded-md px-4 py-2 mb-4">
                      <SelectValue placeholder="اختر المسلسل" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">اختر المسلسل</SelectItem>
                    {series.filter(s => s.type === 'series').map(s => (
                      <SelectItem key={s.id} value={s.id.toString()}>
                        {s.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="episodeNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رقم الحلقة</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min={1}
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="duration"
            render={({ field }) => (
              <FormItem>
                <FormLabel>مدة الحلقة (بالدقائق)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min={1}
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="mb-4">
            <FormLabel htmlFor="thumbnail">صورة الحلقة</FormLabel>
            <div className="relative">
              <Input 
                type="file" 
                id="thumbnail" 
                className="hidden"
                accept="image/*"
                onChange={handleThumbnailChange}
              />
              <label 
                htmlFor="thumbnail" 
                className="admin-input w-full rounded-md px-4 py-10 flex flex-col items-center justify-center cursor-pointer"
              >
                {thumbnailPreview ? (
                  <div className="relative w-full h-40">
                    <img 
                      src={thumbnailPreview} 
                      alt="معاينة" 
                      className="w-full h-full object-contain"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setThumbnail(null);
                        setThumbnailPreview("");
                      }}
                    >
                      إزالة
                    </Button>
                  </div>
                ) : (
                  <>
                    <i className="fas fa-cloud-upload-alt text-2xl mb-2"></i>
                    <span>اضغط لاختيار صورة</span>
                  </>
                )}
              </label>
            </div>
          </div>
        </div>

        <div>
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>عنوان الحلقة (اختياري)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="أدخل عنوان الحلقة (اختياري)" 
                    {...field} 
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وصف الحلقة</FormLabel>
                <FormControl>
                  <Textarea 
                    rows={5}
                    placeholder="أدخل وصف الحلقة"
                    {...field}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4 resize-none"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="videoUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رابط الفيديو</FormLabel>
                <FormControl>
                  <Input 
                    type="url" 
                    placeholder="أدخل رابط الفيديو"
                    {...field}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="mb-4">
            <FormLabel htmlFor="subtitle_file">ملف الترجمة (اختياري)</FormLabel>
            <div className="relative">
              <Input 
                type="file" 
                id="subtitle_file" 
                className="hidden"
                accept=".vtt,.srt"
                onChange={handleSubtitleChange}
              />
              <label 
                htmlFor="subtitle_file" 
                className="admin-input w-full rounded-md px-4 py-2 flex items-center justify-between cursor-pointer"
              >
                <span>{subtitleFile ? subtitleFile.name : "اختر ملف الترجمة"}</span>
                <i className="fas fa-file-alt"></i>
              </label>
            </div>
          </div>
        </div>

        <Button 
          type="submit"
          className="bg-primary hover:bg-primary/90 text-white font-bold py-2 px-6 rounded-md transition mt-4 md:col-span-2"
          disabled={createEpisodeMutation.isPending}
        >
          {createEpisodeMutation.isPending ? "جاري الحفظ..." : "حفظ الحلقة"}
        </Button>
      </form>
    </Form>
  );
}
