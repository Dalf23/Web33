import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-card py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h2 className="text-primary text-2xl font-bold mb-2">سينماوي</h2>
            <p className="text-muted-foreground">أفضل موقع لمشاهدة المسلسلات والأفلام المترجمة</p>
          </div>
          <div className="flex flex-col md:flex-row md:space-x-8 md:space-x-reverse">
            <div className="mb-6 md:mb-0">
              <h3 className="text-foreground font-bold mb-3">روابط سريعة</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/">
                    <a className="text-muted-foreground hover:text-primary transition">الرئيسية</a>
                  </Link>
                </li>
                <li>
                  <Link href="/?type=series">
                    <a className="text-muted-foreground hover:text-primary transition">مسلسلات</a>
                  </Link>
                </li>
                <li>
                  <Link href="/?type=movie">
                    <a className="text-muted-foreground hover:text-primary transition">أفلام</a>
                  </Link>
                </li>
                <li>
                  <Link href="/?sort=new">
                    <a className="text-muted-foreground hover:text-primary transition">المضاف حديثاً</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-foreground font-bold mb-3">تواصل معنا</h3>
              <div className="flex space-x-4 space-x-reverse">
                <a href="#" className="text-muted-foreground hover:text-primary transition text-xl">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition text-xl">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition text-xl">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition text-xl">
                  <i className="fab fa-telegram"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
          <p>جميع الحقوق محفوظة © سينماوي {new Date().getFullYear()}</p>
        </div>
      </div>
    </footer>
  );
}
