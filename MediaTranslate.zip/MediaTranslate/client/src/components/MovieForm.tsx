import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertSeriesSchema, InsertSeries } from "@shared/schema";
import { z } from "zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

// Extend the insert schema with additional validation
const formSchema = insertSeriesSchema.extend({
  title: z.string().min(2, {
    message: "يجب أن يكون العنوان أكثر من حرفين",
  }),
  description: z.string().min(10, {
    message: "يجب أن يكون الوصف أكثر من 10 أحرف",
  }),
  year: z.number().int().min(1900).max(new Date().getFullYear() + 1),
  duration: z.number().int().min(1, {
    message: "يجب أن تكون المدة أكبر من صفر",
  }).optional(),
  videoUrl: z.string().url({
    message: "يجب أن يكون رابط صحيح",
  }).optional()
});

export default function MovieForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string>("");
  const [subtitleFile, setSubtitleFile] = useState<File | null>(null);
  
  // Define form with react-hook-form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      genre: "دراما",
      year: new Date().getFullYear(),
      isFeatured: false,
      type: "movie",
      duration: 90,
      videoUrl: ""
    },
  });
  
  // Handle thumbnail selection
  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setThumbnail(file);
      
      // Preview
      const reader = new FileReader();
      reader.onload = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle subtitle file selection
  const handleSubtitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSubtitleFile(e.target.files[0]);
    }
  };
  
  // Create movie mutation
  const createMovieMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      // In a real implementation, we would handle file uploads here
      // For this demo, we'll just use the URL field
      
      const movieData = {
        ...data,
        thumbnailUrl: thumbnailPreview || undefined,
        subtitleUrl: subtitleFile ? URL.createObjectURL(subtitleFile) : undefined
      };
      
      const res = await apiRequest("POST", "/api/series", movieData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة الفيلم بنجاح",
        description: "تمت إضافة الفيلم إلى قاعدة البيانات"
      });
      
      // Reset form
      form.reset({
        title: "",
        description: "",
        genre: "دراما",
        year: new Date().getFullYear(),
        isFeatured: false,
        type: "movie",
        duration: 90,
        videoUrl: ""
      });
      setThumbnail(null);
      setThumbnailPreview("");
      setSubtitleFile(null);
      
      // Invalidate queries to refetch the data
      queryClient.invalidateQueries({ queryKey: ['/api/series'] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إضافة الفيلم",
        description: error.message || "حدث خطأ أثناء إضافة الفيلم",
        variant: "destructive"
      });
    }
  });
  
  // Submit handler
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    createMovieMutation.mutate(data);
  };
  
  const genres = ["دراما", "كوميديا", "أكشن", "خيال علمي", "رعب", "غموض"];
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>عنوان الفيلم</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="أدخل عنوان الفيلم" 
                    {...field} 
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="genre"
            render={({ field }) => (
              <FormItem>
                <FormLabel>التصنيف</FormLabel>
                <Select 
                  onValueChange={field.onChange} 
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger className="admin-input w-full rounded-md px-4 py-2 mb-4">
                      <SelectValue placeholder="اختر التصنيف" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {genres.map(genre => (
                      <SelectItem key={genre} value={genre}>
                        {genre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="year"
            render={({ field }) => (
              <FormItem>
                <FormLabel>سنة الإنتاج</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min={1900}
                    max={new Date().getFullYear() + 1}
                    {...field}
                    onChange={e => field.onChange(parseInt(e.target.value))}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="duration"
            render={({ field }) => (
              <FormItem>
                <FormLabel>مدة الفيلم (بالدقائق)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min={1}
                    {...field}
                    onChange={e => field.onChange(parseInt(e.target.value))}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="mb-4">
            <FormLabel htmlFor="movie_thumbnail">صورة الغلاف</FormLabel>
            <div className="relative">
              <Input 
                type="file" 
                id="movie_thumbnail" 
                className="hidden"
                accept="image/*"
                onChange={handleThumbnailChange}
              />
              <label 
                htmlFor="movie_thumbnail" 
                className="admin-input w-full rounded-md px-4 py-10 flex flex-col items-center justify-center cursor-pointer"
              >
                {thumbnailPreview ? (
                  <div className="relative w-full h-40">
                    <img 
                      src={thumbnailPreview} 
                      alt="معاينة" 
                      className="w-full h-full object-contain"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setThumbnail(null);
                        setThumbnailPreview("");
                      }}
                    >
                      إزالة
                    </Button>
                  </div>
                ) : (
                  <>
                    <i className="fas fa-cloud-upload-alt text-2xl mb-2"></i>
                    <span>اضغط لاختيار صورة</span>
                  </>
                )}
              </label>
            </div>
          </div>
        </div>

        <div>
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وصف الفيلم</FormLabel>
                <FormControl>
                  <Textarea 
                    rows={5}
                    placeholder="أدخل وصف الفيلم"
                    {...field}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4 resize-none"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="videoUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رابط الفيديو</FormLabel>
                <FormControl>
                  <Input 
                    type="url" 
                    placeholder="أدخل رابط الفيديو"
                    {...field}
                    className="admin-input w-full rounded-md px-4 py-2 mb-4"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="mb-4">
            <FormLabel htmlFor="movie_subtitle">ملف الترجمة (اختياري)</FormLabel>
            <div className="relative">
              <Input 
                type="file" 
                id="movie_subtitle" 
                className="hidden"
                accept=".vtt,.srt"
                onChange={handleSubtitleChange}
              />
              <label 
                htmlFor="movie_subtitle" 
                className="admin-input w-full rounded-md px-4 py-2 flex items-center justify-between cursor-pointer"
              >
                <span>{subtitleFile ? subtitleFile.name : "اختر ملف الترجمة"}</span>
                <i className="fas fa-file-alt"></i>
              </label>
            </div>
          </div>

          <FormField
            control={form.control}
            name="isFeatured"
            render={({ field }) => (
              <FormItem className="flex items-center space-x-2 space-x-reverse mb-4">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <FormLabel className="mr-2">إضافة إلى القسم المميز</FormLabel>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button 
          type="submit"
          className="bg-primary hover:bg-primary/90 text-white font-bold py-2 px-6 rounded-md transition mt-4 md:col-span-2"
          disabled={createMovieMutation.isPending}
        >
          {createMovieMutation.isPending ? "جاري الحفظ..." : "حفظ الفيلم"}
        </Button>
      </form>
    </Form>
  );
}
