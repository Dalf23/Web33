import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import SearchBar from "./SearchBar";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

export default function Navbar() {
  const [isSticky, setIsSticky] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [location] = useLocation();
  
  // Check if user is logged in
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    setIsLoggedIn(!!token);
  }, [location]);
  
  // Handle sticky navbar on scroll
  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 20);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`bg-card py-3 px-4 shadow-md z-50 ${isSticky ? 'sticky top-0' : ''}`}>
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <a className="text-primary text-3xl font-bold ml-2">سينماوي</a>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex mr-10 space-x-6 space-x-reverse">
            <Link href="/">
              <a className={`hover:text-primary transition ${location === '/' ? 'text-primary' : 'text-foreground'}`}>
                الرئيسية
              </a>
            </Link>
            <Link href="/?type=series">
              <a className={`hover:text-primary transition ${location.includes('type=series') ? 'text-primary' : 'text-foreground'}`}>
                مسلسلات
              </a>
            </Link>
            <Link href="/?type=movie">
              <a className={`hover:text-primary transition ${location.includes('type=movie') ? 'text-primary' : 'text-foreground'}`}>
                أفلام
              </a>
            </Link>
            <Link href="/?sort=new">
              <a className={`hover:text-primary transition ${location.includes('sort=new') ? 'text-primary' : 'text-foreground'}`}>
                المضاف حديثاً
              </a>
            </Link>
          </div>
        </div>
        
        <div className="flex items-center space-x-4 space-x-reverse">
          <SearchBar />
          
          {isLoggedIn ? (
            <Link href="/admin">
              <Button variant="default" className="hidden md:block">
                لوحة التحكم
              </Button>
            </Link>
          ) : (
            <Link href="/login">
              <Button variant="default" className="hidden md:block">
                تسجيل الدخول
              </Button>
            </Link>
          )}
          
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-card w-[250px]">
              <div className="flex flex-col space-y-3 mt-6">
                <Link href="/">
                  <a className="text-foreground hover:text-primary transition py-2 border-b border-border">
                    الرئيسية
                  </a>
                </Link>
                <Link href="/?type=series">
                  <a className="text-foreground hover:text-primary transition py-2 border-b border-border">
                    مسلسلات
                  </a>
                </Link>
                <Link href="/?type=movie">
                  <a className="text-foreground hover:text-primary transition py-2 border-b border-border">
                    أفلام
                  </a>
                </Link>
                <Link href="/?sort=new">
                  <a className="text-foreground hover:text-primary transition py-2 border-b border-border">
                    المضاف حديثاً
                  </a>
                </Link>
                {isLoggedIn ? (
                  <Link href="/admin">
                    <a className="text-primary hover:text-primary/90 transition py-2">
                      لوحة التحكم
                    </a>
                  </Link>
                ) : (
                  <Link href="/login">
                    <a className="text-primary hover:text-primary/90 transition py-2">
                      تسجيل الدخول
                    </a>
                  </Link>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
