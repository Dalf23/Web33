import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, X } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";

export default function SearchBar() {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);

  // Enable keyboard shortcut to open search
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  // Search query
  const { data, isLoading } = useQuery({
    queryKey: ['/api/search', searchTerm],
    queryFn: () => 
      fetch(`/api/search?q=${encodeURIComponent(searchTerm)}`)
        .then(res => res.json()),
    enabled: open && searchTerm.length >= 2
  });

  const handleSearch = () => {
    if (searchTerm.trim().length >= 2) {
      setOpen(true);
    }
  };

  const handleSelect = (item: any) => {
    setOpen(false);
    if (item.episodeNumber) {
      // It's an episode
      navigate(`/episode/${item.id}`);
    } else {
      // It's a series or movie
      navigate(`/series/${item.id}`);
    }
  };

  return (
    <>
      <div className="relative">
        <Input
          type="text" 
          placeholder="ابحث عن مسلسل أو فيلم..." 
          className="bg-card px-4 py-2 rounded-full text-foreground pr-10 w-40 md:w-64 focus:outline-none focus:ring-1 focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSearch();
            }
          }}
        />
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleSearch}
          className="absolute right-1 top-1/2 transform -translate-y-1/2 text-muted-foreground h-7 w-7"
        >
          <SearchIcon className="h-4 w-4" />
        </Button>
      </div>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput 
          placeholder="اكتب للبحث..." 
          value={searchTerm}
          onValueChange={setSearchTerm}
          ref={inputRef}
        />
        <CommandList>
          {isLoading && (
            <div className="py-6 text-center text-sm text-muted-foreground">
              جاري البحث...
            </div>
          )}
          
          {!isLoading && searchTerm.length < 2 && (
            <div className="py-6 text-center text-sm text-muted-foreground">
              اكتب حرفين على الأقل للبحث
            </div>
          )}
          
          <CommandEmpty>لا توجد نتائج مطابقة</CommandEmpty>
          
          {data && data.length > 0 && (
            <CommandGroup heading="نتائج البحث">
              {data.map((item: any) => (
                <CommandItem
                  key={`${item.type || 'episode'}-${item.id}`}
                  onSelect={() => handleSelect(item)}
                >
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-card rounded overflow-hidden mr-2">
                      {item.thumbnailUrl && (
                        <img 
                          src={item.thumbnailUrl} 
                          alt="" 
                          className="w-full h-full object-cover" 
                        />
                      )}
                    </div>
                    <span>
                      {item.title}
                      {item.episodeNumber && ` - الحلقة ${item.episodeNumber}`}
                    </span>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}
