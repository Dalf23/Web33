import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Series schema
export const series = pgTable("series", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  bannerUrl: text("banner_url"),
  genre: text("genre").notNull(),
  year: integer("year").notNull(),
  episodeCount: integer("episode_count").default(0),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  type: text("type").notNull().default("series"), // series or movie
  duration: integer("duration"), // for movies only
});

export const insertSeriesSchema = createInsertSchema(series).omit({
  id: true,
  episodeCount: true,
  createdAt: true,
});

// Episode schema
export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  seriesId: integer("series_id").notNull(),
  title: text("title"),
  description: text("description").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  videoUrl: text("video_url").notNull(),
  subtitleUrl: text("subtitle_url"),
  duration: integer("duration").notNull(),
  episodeNumber: integer("episode_number").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertEpisodeSchema = createInsertSchema(episodes).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Series = typeof series.$inferSelect;
export type InsertSeries = z.infer<typeof insertSeriesSchema>;

export type Episode = typeof episodes.$inferSelect;
export type InsertEpisode = z.infer<typeof insertEpisodeSchema>;

// For file-based storage, we'll define additional interfaces
export interface SeriesWithEpisodes extends Series {
  episodes: Episode[];
}
