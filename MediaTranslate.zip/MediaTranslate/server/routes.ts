import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import fs from "fs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { insertEpisodeSchema, insertSeriesSchema, insertUserSchema } from "@shared/schema";
import { fileURLToPath } from "url";
import session from "express-session";
import bcrypt from "bcryptjs";

// Create uploads directory if it doesn't exist
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UPLOADS_DIR = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Helper function for uploading files
function getFileExtension(filename: string): string {
  return path.extname(filename).toLowerCase();
}

function generateTokens(userId: number, username: string): { accessToken: string; } {
  const JWT_SECRET = process.env.JWT_SECRET || "super-secret-jwt-key";
  
  const accessToken = jwt.sign(
    { userId, username },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
  
  return { accessToken };
}

interface JwtPayload {
  userId: number;
  username: string;
  iat?: number;
  exp?: number;
}

function authenticateJWT(req: Request, res: Response, next: () => void) {
  const authHeader = req.headers.authorization;
  
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    const JWT_SECRET = process.env.JWT_SECRET || "super-secret-jwt-key";
    
    try {
      // تسجيل معلومات الرمز للتشخيص
      console.log('Received token:', token);
      
      const user = jwt.verify(token, JWT_SECRET) as JwtPayload;
      (req as any).user = user;
      
      // تسجيل معلومات المستخدم للتأكد من نجاح التوثيق
      console.log('Authenticated user:', user);
      
      next();
    } catch (err) {
      console.error('JWT verification error:', err);
      return res.status(403).json({ message: "Invalid or expired token" });
    }
  } else {
    console.log('No authorization header found');
    res.status(401).json({ message: "Authentication token is required" });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // تقديم الملفات المحملة للتنزيل
  app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));
  
  // إضافة معالجة لتقديم الفيديوهات بخاصية التدفق (streaming)
  app.get('/uploads/videos/:filename', (req, res) => {
    const filename = req.params.filename;
    const videoPath = path.join(__dirname, '..', 'uploads', 'videos', filename);
    
    console.log('طلب ملف فيديو:', videoPath);
    
    // التحقق من وجود الملف
    fs.stat(videoPath, (err, stats) => {
      if (err) {
        if (err.code === 'ENOENT') {
          console.log('الملف غير موجود:', videoPath);
          return res.status(404).send('File not found');
        }
        console.error('خطأ في قراءة الملف:', err);
        return res.status(500).send('Error reading file');
      }
      
      // تحديد نوع MIME بناءً على امتداد الملف
      const ext = path.extname(filename).toLowerCase();
      let contentType = 'video/mp4';
      
      switch(ext) {
        case '.mp4': contentType = 'video/mp4'; break;
        case '.webm': contentType = 'video/webm'; break;
        case '.ogg': case '.ogv': contentType = 'video/ogg'; break;
        case '.mov': contentType = 'video/quicktime'; break;
        case '.mkv': contentType = 'video/x-matroska'; break;
        case '.avi': contentType = 'video/avi'; break;
        case '.wmv': contentType = 'video/x-ms-wmv'; break;
        case '.flv': contentType = 'video/x-flv'; break;
        case '.m3u8': contentType = 'application/x-mpegURL'; break;
        case '.mpd': contentType = 'application/dash+xml'; break;
        case '.ts': contentType = 'video/mp2t'; break;
      }
      
      const fileSize = stats.size;
      const range = req.headers.range;
      
      // في حالة وجود طلب تدفق جزئي للملف
      if (range) {
        const parts = range.replace(/bytes=/, '').split('-');
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunkSize = (end - start) + 1;
        
        console.log(`تدفق الفيديو - النطاق: ${start}-${end}, الحجم: ${chunkSize}`);
        
        const file = fs.createReadStream(videoPath, { start, end });
        
        res.writeHead(206, {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunkSize,
          'Content-Type': contentType,
          'Access-Control-Allow-Origin': '*',
          'Cross-Origin-Resource-Policy': 'cross-origin'
        });
        
        file.pipe(res);
      } else {
        // في حالة عدم وجود طلب نطاق، قدم الملف كاملاً
        console.log(`تقديم الفيديو كاملاً - الحجم: ${fileSize}`);
        
        res.writeHead(200, {
          'Content-Length': fileSize,
          'Content-Type': contentType,
          'Access-Control-Allow-Origin': '*',
          'Cross-Origin-Resource-Policy': 'cross-origin'
        });
        
        fs.createReadStream(videoPath).pipe(res);
      }
    });
  });
  
  // تقديم ملفات الترجمة
  app.get('/uploads/subtitles/:filename', (req, res) => {
    const filename = req.params.filename;
    const subtitlePath = path.join(__dirname, '..', 'uploads', 'subtitles', filename);
    
    console.log('طلب ملف ترجمة:', subtitlePath);
    
    // التحقق من وجود الملف
    fs.stat(subtitlePath, (err, stats) => {
      if (err) {
        if (err.code === 'ENOENT') {
          return res.status(404).send('Subtitle file not found');
        }
        return res.status(500).send('Error reading subtitle file');
      }
      
      // تحديد نوع MIME بناءً على امتداد الملف
      const ext = path.extname(filename).toLowerCase();
      let contentType = 'text/vtt';
      
      if (ext === '.srt') {
        contentType = 'application/x-subrip';
      }
      
      res.setHeader('Content-Type', contentType);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
      
      fs.createReadStream(subtitlePath).pipe(res);
    });
  });
  
  // Setup session
  app.use(session({
    secret: process.env.SESSION_SECRET || 'super-secret-session-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 } // 7 days
  }));
  
  // Default user setup (if none exists)
  const defaultAdmin = await storage.getUserByUsername("admin");
  if (!defaultAdmin) {
    const hashedPassword = await bcrypt.hash("admin", 10);
    await storage.createUser({
      username: "admin",
      password: hashedPassword,
      isAdmin: true
    });
  }
  
  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: validation.error.errors 
        });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validation.data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(validation.data.password, 10);
      
      // Create user (with isAdmin defaulting to false for registered users)
      const user = await storage.createUser({ 
        ...validation.data, 
        password: hashedPassword,
        isAdmin: false
      });
      
      // Return created user without password
      res.status(201).json({
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin,
        createdAt: user.createdAt
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: "Internal server error during registration" });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const tokens = generateTokens(user.id, user.username);
      
      res.json({
        user: { 
          id: user.id, 
          username: user.username,
          isAdmin: user.isAdmin
        },
        ...tokens
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Check authentication status
  app.get('/api/auth/me', authenticateJWT, async (req, res) => {
    try {
      const { userId } = (req as any).user;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        user: {
          id: user.id,
          username: user.username,
          isAdmin: user.isAdmin
        }
      });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Series routes
  app.get('/api/series', async (req, res) => {
    try {
      let series;
      
      if (req.query.type === 'series' || req.query.type === 'movie') {
        series = await storage.getSeriesByType(req.query.type);
      } else if (req.query.featured === 'true') {
        series = await storage.getFeaturedSeries();
      } else if (req.query.genre) {
        series = await storage.getSeriesByGenre(req.query.genre as string);
      } else if (req.query.year) {
        series = await storage.getSeriesByYear(parseInt(req.query.year as string));
      } else {
        series = await storage.getAllSeries();
      }
      
      res.json(series);
    } catch (error) {
      console.error('Get series error:', error);
      res.status(500).json({ message: "Failed to fetch series" });
    }
  });
  
  app.get('/api/series/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const series = await storage.getSeriesWithEpisodes(id);
      
      if (!series) {
        return res.status(404).json({ message: "Series not found" });
      }
      
      res.json(series);
    } catch (error) {
      console.error('Get series details error:', error);
      res.status(500).json({ message: "Failed to fetch series details" });
    }
  });
  
  app.post('/api/series', authenticateJWT, async (req, res) => {
    try {
      const validation = insertSeriesSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid series data", 
          errors: validation.error.errors 
        });
      }
      
      const series = await storage.createSeries(validation.data);
      res.status(201).json(series);
    } catch (error) {
      console.error('Create series error:', error);
      res.status(500).json({ message: "Failed to create series" });
    }
  });
  
  app.put('/api/series/:id', authenticateJWT, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingSeries = await storage.getSeriesById(id);
      
      if (!existingSeries) {
        return res.status(404).json({ message: "Series not found" });
      }
      
      const updatedSeries = await storage.updateSeries(id, req.body);
      res.json(updatedSeries);
    } catch (error) {
      console.error('Update series error:', error);
      res.status(500).json({ message: "Failed to update series" });
    }
  });
  
  app.delete('/api/series/:id', authenticateJWT, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteSeries(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Series not found" });
      }
      
      res.json({ message: "Series deleted successfully" });
    } catch (error) {
      console.error('Delete series error:', error);
      res.status(500).json({ message: "Failed to delete series" });
    }
  });
  
  // Episode routes
  app.get('/api/episodes/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const episode = await storage.getEpisodeById(id);
      
      if (!episode) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      res.json(episode);
    } catch (error) {
      console.error('Get episode error:', error);
      res.status(500).json({ message: "Failed to fetch episode" });
    }
  });
  
  app.post('/api/episodes', authenticateJWT, async (req, res) => {
    try {
      const validation = insertEpisodeSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid episode data", 
          errors: validation.error.errors 
        });
      }
      
      // Verify that the series exists
      const series = await storage.getSeriesById(validation.data.seriesId);
      if (!series) {
        return res.status(404).json({ message: "Series not found" });
      }
      
      const episode = await storage.createEpisode(validation.data);
      res.status(201).json(episode);
    } catch (error) {
      console.error('Create episode error:', error);
      res.status(500).json({ message: "Failed to create episode" });
    }
  });
  
  app.put('/api/episodes/:id', authenticateJWT, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingEpisode = await storage.getEpisodeById(id);
      
      if (!existingEpisode) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      const updatedEpisode = await storage.updateEpisode(id, req.body);
      res.json(updatedEpisode);
    } catch (error) {
      console.error('Update episode error:', error);
      res.status(500).json({ message: "Failed to update episode" });
    }
  });
  
  app.delete('/api/episodes/:id', authenticateJWT, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteEpisode(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      res.json({ message: "Episode deleted successfully" });
    } catch (error) {
      console.error('Delete episode error:', error);
      res.status(500).json({ message: "Failed to delete episode" });
    }
  });
  
  // Search route
  app.get('/api/search', async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query || query.trim().length < 2) {
        return res.status(400).json({ message: "Search query must be at least 2 characters" });
      }
      
      const results = await storage.searchContent(query);
      res.json(results);
    } catch (error) {
      console.error('Search error:', error);
      res.status(500).json({ message: "Failed to perform search" });
    }
  });
  
  return httpServer;
}
