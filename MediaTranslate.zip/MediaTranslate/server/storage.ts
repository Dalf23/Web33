import { promises as fs } from 'fs';
import path from 'path';
import { 
  User, InsertUser, 
  Series, InsertSeries, 
  Episode, InsertEpisode,
  SeriesWithEpisodes 
} from '@shared/schema';

const DATA_DIR = path.join(process.cwd(), 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SERIES_FILE = path.join(DATA_DIR, 'series.json');
const EPISODES_FILE = path.join(DATA_DIR, 'episodes.json');

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create data directory:', error);
  }
}

// Helper functions for file operations
async function readJsonFile<T>(filePath: string, defaultValue: T): Promise<T> {
  try {
    const data = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(data) as T;
  } catch (error) {
    // If file doesn't exist, return default value
    await fs.writeFile(filePath, JSON.stringify(defaultValue, null, 2));
    return defaultValue;
  }
}

async function writeJsonFile<T>(filePath: string, data: T): Promise<void> {
  await fs.writeFile(filePath, JSON.stringify(data, null, 2));
}

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Series operations
  getAllSeries(): Promise<Series[]>;
  getSeriesById(id: number): Promise<Series | undefined>;
  createSeries(series: InsertSeries): Promise<Series>;
  updateSeries(id: number, series: Partial<Series>): Promise<Series | undefined>;
  deleteSeries(id: number): Promise<boolean>;
  getSeriesByType(type: 'series' | 'movie'): Promise<Series[]>;
  getFeaturedSeries(): Promise<Series[]>;
  
  // Episode operations
  getEpisodesBySeriesId(seriesId: number): Promise<Episode[]>;
  getEpisodeById(id: number): Promise<Episode | undefined>;
  createEpisode(episode: InsertEpisode): Promise<Episode>;
  updateEpisode(id: number, episode: Partial<Episode>): Promise<Episode | undefined>;
  deleteEpisode(id: number): Promise<boolean>;
  
  // Combined operations
  getSeriesWithEpisodes(seriesId: number): Promise<SeriesWithEpisodes | undefined>;
  searchContent(query: string): Promise<(Series | Episode)[]>;
  getSeriesByGenre(genre: string): Promise<Series[]>;
  getSeriesByYear(year: number): Promise<Series[]>;
}

export class FileStorage implements IStorage {
  private users: User[] = [];
  private series: Series[] = [];
  private episodes: Episode[] = [];
  private initialized = false;
  
  private async initialize() {
    if (this.initialized) return;
    
    await ensureDataDir();
    
    this.users = await readJsonFile<User[]>(USERS_FILE, []);
    this.series = await readJsonFile<Series[]>(SERIES_FILE, []);
    this.episodes = await readJsonFile<Episode[]>(EPISODES_FILE, []);
    
    this.initialized = true;
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    await this.initialize();
    return this.users.find(user => user.id === id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    await this.initialize();
    return this.users.find(user => user.username === username);
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    await this.initialize();
    const id = this.users.length > 0 ? Math.max(...this.users.map(u => u.id)) + 1 : 1;
    const user: User = { 
      ...userData, 
      id, 
      isAdmin: userData.isAdmin ?? false,
      createdAt: new Date() 
    };
    
    this.users.push(user);
    await writeJsonFile(USERS_FILE, this.users);
    
    return user;
  }
  
  // Series methods
  async getAllSeries(): Promise<Series[]> {
    await this.initialize();
    return [...this.series];
  }
  
  async getSeriesById(id: number): Promise<Series | undefined> {
    await this.initialize();
    return this.series.find(s => s.id === id);
  }
  
  async createSeries(seriesData: InsertSeries): Promise<Series> {
    await this.initialize();
    const id = this.series.length > 0 ? Math.max(...this.series.map(s => s.id)) + 1 : 1;
    const createdAt = new Date();
    
    // Make sure required fields have default values
    const series: Series = { 
      ...seriesData, 
      id, 
      type: seriesData.type || 'series',
      duration: seriesData.duration || null,
      thumbnailUrl: seriesData.thumbnailUrl || null,
      bannerUrl: seriesData.bannerUrl || null,
      episodeCount: 0,
      isFeatured: seriesData.isFeatured || false,
      createdAt 
    };
    
    this.series.push(series);
    await writeJsonFile(SERIES_FILE, this.series);
    
    return series;
  }
  
  async updateSeries(id: number, seriesData: Partial<Series>): Promise<Series | undefined> {
    await this.initialize();
    const index = this.series.findIndex(s => s.id === id);
    if (index === -1) return undefined;
    
    const updatedSeries = { ...this.series[index], ...seriesData };
    this.series[index] = updatedSeries;
    
    await writeJsonFile(SERIES_FILE, this.series);
    return updatedSeries;
  }
  
  async deleteSeries(id: number): Promise<boolean> {
    await this.initialize();
    const initialLength = this.series.length;
    this.series = this.series.filter(s => s.id !== id);
    
    // Also delete associated episodes
    this.episodes = this.episodes.filter(e => e.seriesId !== id);
    
    await writeJsonFile(SERIES_FILE, this.series);
    await writeJsonFile(EPISODES_FILE, this.episodes);
    
    return initialLength > this.series.length;
  }
  
  async getSeriesByType(type: 'series' | 'movie'): Promise<Series[]> {
    await this.initialize();
    return this.series.filter(s => s.type === type);
  }
  
  async getFeaturedSeries(): Promise<Series[]> {
    await this.initialize();
    return this.series.filter(s => s.isFeatured);
  }
  
  // Episode methods
  async getEpisodesBySeriesId(seriesId: number): Promise<Episode[]> {
    await this.initialize();
    return this.episodes
      .filter(e => e.seriesId === seriesId)
      .sort((a, b) => a.episodeNumber - b.episodeNumber);
  }
  
  async getEpisodeById(id: number): Promise<Episode | undefined> {
    await this.initialize();
    return this.episodes.find(e => e.id === id);
  }
  
  async createEpisode(episodeData: InsertEpisode): Promise<Episode> {
    await this.initialize();
    const id = this.episodes.length > 0 ? Math.max(...this.episodes.map(e => e.id)) + 1 : 1;
    const createdAt = new Date();
    
    // Ensure all required fields have values
    const episode: Episode = { 
      ...episodeData, 
      id, 
      createdAt,
      title: episodeData.title || null,
      thumbnailUrl: episodeData.thumbnailUrl || null,
      subtitleUrl: episodeData.subtitleUrl || null
    };
    
    this.episodes.push(episode);
    
    // Update the episode count for the series
    const seriesIndex = this.series.findIndex(s => s.id === episodeData.seriesId);
    if (seriesIndex !== -1) {
      this.series[seriesIndex] = {
        ...this.series[seriesIndex],
        episodeCount: (this.series[seriesIndex].episodeCount || 0) + 1
      };
    }
    
    await writeJsonFile(EPISODES_FILE, this.episodes);
    await writeJsonFile(SERIES_FILE, this.series);
    
    return episode;
  }
  
  async updateEpisode(id: number, episodeData: Partial<Episode>): Promise<Episode | undefined> {
    await this.initialize();
    const index = this.episodes.findIndex(e => e.id === id);
    if (index === -1) return undefined;
    
    const updatedEpisode = { ...this.episodes[index], ...episodeData };
    this.episodes[index] = updatedEpisode;
    
    await writeJsonFile(EPISODES_FILE, this.episodes);
    return updatedEpisode;
  }
  
  async deleteEpisode(id: number): Promise<boolean> {
    await this.initialize();
    const episode = this.episodes.find(e => e.id === id);
    if (!episode) return false;
    
    const initialLength = this.episodes.length;
    this.episodes = this.episodes.filter(e => e.id !== id);
    
    // Update the episode count for the series
    const seriesIndex = this.series.findIndex(s => s.id === episode.seriesId);
    if (seriesIndex !== -1) {
      const currentCount = this.series[seriesIndex].episodeCount || 0;
      if (currentCount > 0) {
        this.series[seriesIndex] = {
          ...this.series[seriesIndex],
          episodeCount: currentCount - 1
        };
      }
    }
    
    await writeJsonFile(EPISODES_FILE, this.episodes);
    await writeJsonFile(SERIES_FILE, this.series);
    
    return initialLength > this.episodes.length;
  }
  
  // Combined operations
  async getSeriesWithEpisodes(seriesId: number): Promise<SeriesWithEpisodes | undefined> {
    await this.initialize();
    const series = await this.getSeriesById(seriesId);
    if (!series) return undefined;
    
    const episodes = await this.getEpisodesBySeriesId(seriesId);
    return { ...series, episodes };
  }
  
  async searchContent(query: string): Promise<(Series | Episode)[]> {
    await this.initialize();
    const normalizedQuery = query.toLowerCase();
    
    const matchingSeries = this.series.filter(s => 
      s.title.toLowerCase().includes(normalizedQuery) || 
      s.description.toLowerCase().includes(normalizedQuery)
    );
    
    const matchingEpisodes = this.episodes.filter(e => 
      (e.title && e.title.toLowerCase().includes(normalizedQuery)) || 
      e.description.toLowerCase().includes(normalizedQuery)
    );
    
    return [...matchingSeries, ...matchingEpisodes];
  }
  
  async getSeriesByGenre(genre: string): Promise<Series[]> {
    await this.initialize();
    return this.series.filter(s => s.genre === genre);
  }
  
  async getSeriesByYear(year: number): Promise<Series[]> {
    await this.initialize();
    return this.series.filter(s => s.year === year);
  }
}

// Import and use the database storage instead of file storage
import { DatabaseStorage } from './db-storage';
export const storage = new DatabaseStorage();
