import session from 'express-session';
import connectPg from 'connect-pg-simple';
import pkg from 'pg';
const { Pool } = pkg;
import bcrypt from 'bcryptjs';
import { 
  User, InsertUser, 
  Series, InsertSeries, 
  Episode, InsertEpisode,
  SeriesWithEpisodes,
  users, series, episodes 
} from '@shared/schema';
import { IStorage } from './storage';
import * as db from './db';
import { eq, ilike } from 'drizzle-orm';

// Setup PostgreSQL session store
const PostgresSessionStore = connectPg(session);
const pgPool = new Pool({
  connectionString: process.env.DATABASE_URL
});

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;
  
  constructor() {
    // Initialize session store
    this.sessionStore = new PostgresSessionStore({
      pool: pgPool,
      createTableIfMissing: true
    });
    
    // Initialize database
    this.initialize();
  }
  
  private async initialize() {
    try {
      // Initialize the database (create tables, etc.)
      await db.initializeDatabase();
      
      // Create default admin user if needed
      await this.createDefaultAdmin();
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }
  
  private async createDefaultAdmin() {
    try {
      const admin = await this.getUserByUsername('admin');
      if (!admin) {
        const hashedPassword = await bcrypt.hash('admin', 10);
        await this.createUser({
          username: 'admin',
          password: hashedPassword,
          isAdmin: true
        });
        console.log('Default admin user created successfully');
      }
    } catch (error) {
      console.error('Failed to create default admin:', error);
    }
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const userResult = await db.getUserById(id);
    if (!userResult || userResult.length === 0) return undefined;
    return userResult[0];
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const user = await db.getUserByUsername(username);
    return user ? user : undefined;
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    // Insert into database using drizzle ORM
    const result = await db.db.insert(users).values(userData).returning();
    return result[0];
  }
  
  // Series methods
  async getAllSeries(): Promise<Series[]> {
    return db.getAllSeries();
  }
  
  async getSeriesById(id: number): Promise<Series | undefined> {
    const result = await db.getSeriesById(id);
    return result ? result : undefined;
  }
  
  async createSeries(seriesData: InsertSeries): Promise<Series> {
    const result = await db.db.insert(series).values({
      ...seriesData,
      episodeCount: 0
    }).returning();
    return result[0];
  }
  
  async updateSeries(id: number, seriesData: Partial<Series>): Promise<Series | undefined> {
    const result = await db.db.update(series)
      .set(seriesData)
      .where(eq(series.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async deleteSeries(id: number): Promise<boolean> {
    // First delete all associated episodes
    await db.db.delete(episodes).where(eq(episodes.seriesId, id));
    
    // Then delete the series
    const result = await db.db.delete(series).where(eq(series.id, id)).returning();
    return result.length > 0;
  }
  
  async getSeriesByType(type: 'series' | 'movie'): Promise<Series[]> {
    return db.getSeriesByType(type);
  }
  
  async getFeaturedSeries(): Promise<Series[]> {
    return db.getFeaturedSeries();
  }
  
  // Episode methods
  async getEpisodesBySeriesId(seriesId: number): Promise<Episode[]> {
    return db.getEpisodesBySeriesId(seriesId);
  }
  
  async getEpisodeById(id: number): Promise<Episode | undefined> {
    const episode = await db.getEpisodeById(id);
    return episode ? episode : undefined;
  }
  
  async createEpisode(episodeData: InsertEpisode): Promise<Episode> {
    // Insert the episode
    const result = await db.db.insert(episodes).values(episodeData).returning();
    
    // Update episode count for the series
    const series = await this.getSeriesById(episodeData.seriesId);
    if (series) {
      await this.updateSeries(series.id, { 
        episodeCount: (series.episodeCount || 0) + 1 
      });
    }
    
    return result[0];
  }
  
  async updateEpisode(id: number, episodeData: Partial<Episode>): Promise<Episode | undefined> {
    const result = await db.db.update(episodes)
      .set(episodeData)
      .where(eq(episodes.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async deleteEpisode(id: number): Promise<boolean> {
    // Get the episode first to know its series
    const episode = await this.getEpisodeById(id);
    if (!episode) return false;
    
    // Delete the episode
    const result = await db.db.delete(episodes).where(eq(episodes.id, id)).returning();
    
    // If successful, update the episode count for the series
    if (result.length > 0) {
      const series = await this.getSeriesById(episode.seriesId);
      if (series && series.episodeCount && series.episodeCount > 0) {
        await this.updateSeries(series.id, { 
          episodeCount: series.episodeCount - 1 
        });
      }
      return true;
    }
    
    return false;
  }
  
  // Combined operations
  async getSeriesWithEpisodes(seriesId: number): Promise<SeriesWithEpisodes | undefined> {
    const result = await db.getSeriesWithEpisodes(seriesId);
    return result ? {
      ...result,
      episodes: result.episodes || []
    } : undefined;
  }
  
  async searchContent(query: string): Promise<(Series | Episode)[]> {
    return db.searchContent(query);
  }
  
  async getSeriesByGenre(genre: string): Promise<Series[]> {
    // Search series by genre
    const results = await db.db.select().from(series).where(
      ilike(series.genre, `%${genre}%`)
    );
    return results;
  }
  
  async getSeriesByYear(year: number): Promise<Series[]> {
    // Search series by year
    const results = await db.db.select().from(series).where(eq(series.year, year));
    return results;
  }
}