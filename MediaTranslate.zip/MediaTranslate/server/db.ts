import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import { users, series, episodes } from '@shared/schema';
import { eq, ilike } from 'drizzle-orm';
import bcrypt from "bcryptjs";

// Check if DATABASE_URL is defined
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is not defined');
}

// Database client
const connectionString = process.env.DATABASE_URL;
const client = postgres(connectionString);
export const db = drizzle(client);

// Migrations setup
export async function runMigrations() {
  console.log('Running migrations...');
  try {
    await migrate(db, { migrationsFolder: 'drizzle' });
    console.log('Migrations completed successfully');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}

// Create database schema
export async function createSchema() {
  console.log('Creating database schema...');
  try {
    // Create tables
    const queries = [
      `CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        is_admin BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`,
      `CREATE TABLE IF NOT EXISTS series (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        thumbnail_url TEXT,
        banner_url TEXT,
        genre TEXT NOT NULL,
        year INTEGER NOT NULL,
        episode_count INTEGER DEFAULT 0,
        is_featured BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        type TEXT NOT NULL DEFAULT 'series',
        duration INTEGER
      )`,
      `CREATE TABLE IF NOT EXISTS episodes (
        id SERIAL PRIMARY KEY,
        series_id INTEGER NOT NULL,
        title TEXT,
        description TEXT NOT NULL,
        thumbnail_url TEXT,
        video_url TEXT NOT NULL,
        subtitle_url TEXT,
        duration INTEGER NOT NULL,
        episode_number INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    for (const query of queries) {
      await client.unsafe(query);
    }

    console.log('Schema created successfully');
  } catch (error) {
    console.error('Schema creation failed:', error);
    throw error;
  }
}

// Initialize database
export async function initializeDatabase() {
  try {
    // Check if tables already exist
    const tablesExist = await client`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      );
    `;
    
    // Only create schema if tables don't exist
    if (!tablesExist[0].exists) {
      await createSchema();
      
      try {
        // Create default admin with hashed password
        console.log('Creating default admin user...');
        const hashedPassword = await bcrypt.hash('admin', 10);
        await client`
          INSERT INTO users (username, password, is_admin)
          VALUES ('admin', ${hashedPassword}, TRUE)
        `;
      } catch (adminError: any) {
        // If error is because admin already exists, ignore it
        if (adminError.code === '23505' && adminError.constraint_name === 'users_username_key') {
          console.log('Admin user already exists, skipping creation');
        } else {
          throw adminError;
        }
      }
    } else {
      console.log('Database tables already exist, skipping initialization');
      
      try {
        // Check for default admin
        const adminExistsResult = await client`
          SELECT * FROM users WHERE username = 'admin' LIMIT 1
        `;
        
        // Create default admin if it doesn't exist
        if (adminExistsResult.length === 0) {
          console.log('Creating default admin user...');
          const hashedPassword = await bcrypt.hash('admin', 10);
          await client`
            INSERT INTO users (username, password, is_admin)
            VALUES ('admin', ${hashedPassword}, TRUE)
          `;
        }
      } catch (adminError: any) {
        // If error is because admin already exists, ignore it
        if (adminError.code === '23505' && adminError.constraint_name === 'users_username_key') {
          console.log('Admin user already exists, skipping creation');
        } else {
          throw adminError;
        }
      }
    }
    console.log('Database initialization completed successfully');
  } catch (error) {
    console.error('Database initialization failed:', error);
    if (error instanceof Error) {
      console.error(error.message);
    }
    // Don't throw the error, just log it and continue
  }
}

// Helper functions for database operations

// Users
export async function getAllUsers() {
  return db.select().from(users);
}

export async function getUserById(id: number) {
  return db.select().from(users).where(eq(users.id, id)).limit(1);
}

export async function getUserByUsername(username: string) {
  const results = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return results.length > 0 ? results[0] : null;
}

// Series
export async function getAllSeries() {
  return db.select().from(series);
}

export async function getSeriesById(id: number) {
  const results = await db.select().from(series).where(eq(series.id, id)).limit(1);
  return results.length > 0 ? results[0] : null;
}

export async function getSeriesByType(type: 'series' | 'movie') {
  return db.select().from(series).where(eq(series.type, type));
}

export async function getFeaturedSeries() {
  return db.select().from(series).where(eq(series.isFeatured, true));
}

// Episodes
export async function getEpisodesBySeriesId(seriesId: number) {
  return db.select().from(episodes).where(eq(episodes.seriesId, seriesId));
}

export async function getEpisodeById(id: number) {
  const results = await db.select().from(episodes).where(eq(episodes.id, id)).limit(1);
  return results.length > 0 ? results[0] : null;
}

// Combined queries
export async function getSeriesWithEpisodes(seriesId: number) {
  const seriesData = await getSeriesById(seriesId);
  if (!seriesData) return null;
  
  const episodesData = await getEpisodesBySeriesId(seriesId);
  return {
    ...seriesData,
    episodes: episodesData
  };
}

export async function searchContent(query: string) {
  // Basic search functionality
  const seriesResults = await db.select().from(series).where(
    ilike(series.title, `%${query}%`)
  );
  
  const episodeResults = await db.select().from(episodes).where(
    ilike(episodes.title!, `%${query}%`)
  );
  
  return [...seriesResults, ...episodeResults];
}